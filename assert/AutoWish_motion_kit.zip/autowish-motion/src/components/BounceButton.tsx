import React from 'react';
import { Pressable, StyleProp, StyleSheet, Text, ViewStyle } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { colors } from '../theme/colors';
import { motion } from '../theme/motion';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

type Props = {
  title: string;
  onPress?: () => void;
  /** primary = orange pill (Write Wish, Schedule Wish); text = quiet link-style button */
  variant?: 'primary' | 'text';
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
};

/** Shrinks to 95% when pressed and springs back with a tiny bounce. */
export function BounceButton({ title, onPress, variant = 'primary', disabled, style }: Props) {
  const reduceMotion = useReducedMotion();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <AnimatedPressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      onPressIn={() => {
        if (!reduceMotion) scale.value = withSpring(motion.press.scale, motion.press.down);
      }}
      onPressOut={() => {
        scale.value = withSpring(1, motion.press.up);
      }}
      style={[
        styles.base,
        variant === 'primary' ? styles.primary : styles.text,
        disabled && styles.disabled,
        style,
        animatedStyle,
      ]}
    >
      <Text style={variant === 'primary' ? styles.primaryLabel : styles.textLabel}>{title}</Text>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  base: {
    minHeight: 52,
    borderRadius: 999,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: { backgroundColor: colors.orange },
  text: { backgroundColor: 'transparent', minHeight: 44 },
  disabled: { opacity: 0.5 },
  // If you load Nunito (e.g. @expo-google-fonts/nunito), set fontFamily here too.
  primaryLabel: { color: colors.text, fontSize: 16, fontWeight: '800' },
  textLabel: { color: colors.textMuted, fontSize: 15, fontWeight: '700' },
});
