// AutoWish brand palette. Use these everywhere instead of typing hex codes,
// so screens, Lottie animations and components always match.

export const colors = {
  // backgrounds
  background: '#F6F5F2', // warm off-white, app background
  surface: '#FFFFFF', // cards, sheets
  surfaceMuted: '#EFEEEC',

  // text
  text: '#2F3550', // dark navy, main text
  textMuted: '#5D6585', // secondary text

  // brand
  pink: '#FFB4B4', // lid, Today card
  pinkLight: '#FDE3E4', // glows, soft fills
  coral: '#F9A39C', // gift box
  heart: '#EF7A70', // heart, success circle
  blue: '#789BD9', // knot, Sent tick, selected chips
  blueLight: '#A9C1E6', // ribbon, trails, z's
  blueMist: '#DAE3EA', // chips, Scheduled pill
  greyBlue: '#A0AFCC',
  orange: '#FFA618', // main buttons and countdowns
  yellow: '#FFD961', // highlights, Today chip
  sparkle: '#F2C94C',
  outline: '#E6DFD3', // soft borders
} as const;

export type ColorName = keyof typeof colors;
